<template>
  <div class="backtop">
    <img src="~assets/img/common/top.png" alt="" />
  </div>
</template>

<script >
export default {
  data() {
    return {};
  },
  components: {},
  methods: {},
};
</script>

<style >
.backtop {
  position: fixed;
  right: 8px;
  bottom: 55px;
}
.backtop img {
  width: 43px;
  height: 43px;
}
</style>
