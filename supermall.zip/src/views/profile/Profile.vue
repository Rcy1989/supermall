<template>
  <div class="">
    <h2>我的</h2>
  </div>
</template>

<script >
  export default {
    name: "",
    data() {
      return {}
    },
    components: {},
    methods: {}
  }
</script>

<style >

</style>
