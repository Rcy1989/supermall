<template>
  <div class="popular">
    <a href="https://act.mogujie.com/zzlx67">
      <img src="~assets/img/home/recommend_bg.jpg" alt="">
    </a>
  </div>
</template>

<script >
  export default {
    data() {
      return {}
    },
    components: {},
    methods: {}
  }
</script>

<style >
  .popular img{
    width: 100vw;
  }
</style>
